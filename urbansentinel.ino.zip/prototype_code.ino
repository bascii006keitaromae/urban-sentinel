/*
  URBAN SENTINEL - STAGED PROTOTYPE
  UPDATED:
  - Rain is now AO-based: rainAO < 2500 => POSITIVE
  - Rain DO is still printed for reference

  Logic:
  1. Read rain sensor and HW-038 first
  2. Print rain status + water level value to Serial
  3. If water level exceeds threshold, activate ultrasonic
  4. Ultrasonic determines flood warning level
  5. Level 3 -> slow beep
     Level 4 -> fast beep
  6. LED behavior follows test-code style

  Wiring:
  Rain sensor:
    AO -> GPIO 34
    DO -> GPIO 27

  HW-038:
    S  -> GPIO 35

  Ultrasonic:
    TRIG -> GPIO 5
    ECHO -> GPIO 18

  RGB LED:
    R -> GPIO 14
    G -> GPIO 12
    B -> GPIO 13
    - -> GND

  Active buzzer:
    SIG -> GPIO 25

  Relay:
    IN -> GPIO 26
*/

const int RAIN_AO_PIN = 34;
const int RAIN_DO_PIN = 27;

const int WATER_AO_PIN = 35;

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;

const int LED_R_PIN = 14;
const int LED_G_PIN = 12;
const int LED_B_PIN = 13;

const int BUZZER_PIN = 25;
const int RELAY_PIN  = 26;

const bool RAIN_DO_WET_IS_LOW = true;
const bool RGB_COMMON_ANODE = false;
const bool RELAY_ACTIVE_LOW = true;

// ---------- THRESHOLDS ----------
const int RAIN_THRESHOLD  = 2500;  // Rain AO < 2500 => POSITIVE
const int WATER_THRESHOLD = 2500;  // HW-038 trigger

// Cup-based ultrasonic levels (cm)
// Smaller distance = higher water
const float LEVEL_1_DIST = 12.0;   // Potential Flood
const float LEVEL_2_DIST = 9.0;    // Warning
const float LEVEL_3_DIST = 6.0;    // Warning Evacuate
const float LEVEL_4_DIST = 3.0;    // Flood

// ---------- STATE ----------
int currentLevel = 0;     // 0 = normal, 1..4 = flood levels
bool ultrasonicActive = false;

void setup() {
  Serial.begin(115200);

  pinMode(RAIN_AO_PIN, INPUT);
  pinMode(RAIN_DO_PIN, INPUT);
  pinMode(WATER_AO_PIN, INPUT);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(LED_R_PIN, OUTPUT);
  pinMode(LED_G_PIN, OUTPUT);
  pinMode(LED_B_PIN, OUTPUT);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(TRIG_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  setRelay(false);

  // Startup test
  setRGB(true, false, false); delay(300);
  setRGB(false, true, false); delay(300);
  setRGB(false, false, true); delay(300);
  setRGB(false, false, false);

  digitalWrite(BUZZER_PIN, HIGH); delay(200);
  digitalWrite(BUZZER_PIN, LOW);

  setRelay(true); delay(300);
  setRelay(false);

  Serial.println("=== URBAN SENTINEL PROTOTYPE START ===");
}

void loop() {
  // -------- 1) READ RAIN --------
  int rainAO = analogRead(RAIN_AO_PIN);
  bool rainRaw = digitalRead(RAIN_DO_PIN);

  // DO reading kept for reference/debug
  bool rainDO_wet = RAIN_DO_WET_IS_LOW ? (rainRaw == LOW) : (rainRaw == HIGH);

  // MAIN rain logic now uses AO threshold
  bool rainWet = (rainAO < RAIN_THRESHOLD);

  // -------- 2) READ WATER SENSOR --------
  int waterValue = analogRead(WATER_AO_PIN);
  bool waterDetected = (waterValue < WATER_THRESHOLD);

  Serial.println("------------------------------------------------");

  Serial.print("Rain AO: ");
  Serial.println(rainAO);

  Serial.print("Rain DO: ");
  Serial.println(rainDO_wet ? "WET" : "DRY");

  Serial.print("Rain Threshold: ");
  Serial.println(RAIN_THRESHOLD);

  Serial.print("Rain: ");
  Serial.println(rainWet ? "POSITIVE" : "NEGATIVE");

  Serial.print("WaterLevel: ");
  Serial.println(waterValue);

  Serial.print("Water Trigger: ");
  Serial.println(waterDetected ? "POSITIVE" : "NEGATIVE");

  // -------- STAGE A: NO WATER TRIGGER YET --------
  if (!waterDetected) {
    ultrasonicActive = false;
    currentLevel = 0;

    if (rainWet) {
      Serial.println("Status: RAIN DETECTED");
      setRGB(false, false, true);   // BLUE
    } else {
      Serial.println("Status: NORMAL");
      setRGB(false, true, false);   // GREEN
    }

    digitalWrite(BUZZER_PIN, LOW);
    setRelay(false);

    delay(1000);
    return;
  }

  // -------- STAGE B: WATER TRIGGERED -> ACTIVATE ULTRASONIC --------
  ultrasonicActive = true;
  Serial.println("Status: WATER DETECTED - ULTRASONIC ACTIVATED");

  float distance = readDistanceCm();

  if (distance < 0) {
    Serial.println("Ultrasonic: FAILED");
    blinkMagenta();
    digitalWrite(BUZZER_PIN, LOW);
    setRelay(false);
    delay(500);
    return;
  }

  Serial.print("Ultrasonic Active: ");
  Serial.println(ultrasonicActive ? "YES" : "NO");

  Serial.print("Ultrasonic Distance (cm): ");
  Serial.println(distance, 2);

  // -------- 3) DETERMINE WARNING LEVEL --------
  if (distance <= LEVEL_4_DIST) {
    currentLevel = 4;
  }
  else if (distance <= LEVEL_3_DIST) {
    currentLevel = 3;
  }
  else if (distance <= LEVEL_2_DIST) {
    currentLevel = 2;
  }
  else if (distance <= LEVEL_1_DIST) {
    currentLevel = 1;
  }
  else {
    currentLevel = 0;
  }

  // -------- 4) OUTPUT LEVEL STATUS --------
  switch (currentLevel) {
    case 0:
      Serial.println("Level 0: Water detected, below flood range");
      setRGB(true, true, false);   // YELLOW
      digitalWrite(BUZZER_PIN, LOW);
      setRelay(false);
      break;

    case 1:
      Serial.println("Level 1: Potential Flood");
      setRGB(true, true, false);   // YELLOW
      digitalWrite(BUZZER_PIN, LOW);
      setRelay(false);
      break;

    case 2:
      Serial.println("Level 2: Warning");
      setRGB(true, true, false);   // YELLOW
      digitalWrite(BUZZER_PIN, LOW);
      setRelay(false);
      break;

    case 3:
      Serial.println("Level 3: Warning Evacuate");
      setRGB(true, false, false);  // RED
      beepSlow();
      setRelay(true);
      break;

    case 4:
      Serial.println("Level 4: Flood");
      setRGB(true, false, false);  // RED
      beepFast();
      setRelay(true);
      break;
  }

  delay(1000);
}

// ---------- ULTRASONIC ----------
float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1.0;

  return duration * 0.0343 / 2.0;
}

// ---------- RGB ----------
void setRGB(bool r, bool g, bool b) {
  if (RGB_COMMON_ANODE) {
    digitalWrite(LED_R_PIN, r ? LOW : HIGH);
    digitalWrite(LED_G_PIN, g ? LOW : HIGH);
    digitalWrite(LED_B_PIN, b ? LOW : HIGH);
  } else {
    digitalWrite(LED_R_PIN, r ? HIGH : LOW);
    digitalWrite(LED_G_PIN, g ? HIGH : LOW);
    digitalWrite(LED_B_PIN, b ? HIGH : LOW);
  }
}

// ---------- RELAY ----------
void setRelay(bool on) {
  if (RELAY_ACTIVE_LOW) {
    digitalWrite(RELAY_PIN, on ? LOW : HIGH);
  } else {
    digitalWrite(RELAY_PIN, on ? HIGH : LOW);
  }
}

// ---------- BUZZER ----------
void beepSlow() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(200);
  digitalWrite(BUZZER_PIN, LOW);
}

void beepFast() {
  for (int i = 0; i < 3; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(100);
    digitalWrite(BUZZER_PIN, LOW);
    delay(100);
  }
}

// ---------- ERROR ----------
void blinkMagenta() {
  setRGB(true, false, true);
  delay(150);
  setRGB(false, false, false);
  delay(150);
}